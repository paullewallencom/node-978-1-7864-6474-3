module.exports = 'I am a file';
