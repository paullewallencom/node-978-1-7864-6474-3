module.exports = "simple module.exports";
