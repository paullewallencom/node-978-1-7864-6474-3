module.exports = subtract;

function subtract(x, y){
  return x - y;
}
